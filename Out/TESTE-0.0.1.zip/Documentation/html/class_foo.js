var class_foo =
[
    [ "structTemplate", "struct_foo_1_1struct_template.html", "struct_foo_1_1struct_template" ],
    [ "EnumClass", "class_foo.html#a15ac327bfeab9942f561dcc535911424", [
      [ "CVal1", "class_foo.html#a15ac327bfeab9942f561dcc535911424acc6f34b358749c5b6cb8b6b1ce999741", null ],
      [ "CVal2", "class_foo.html#a15ac327bfeab9942f561dcc535911424a919dbaad4912d2b0cb87caf51d25a935", null ],
      [ "CVal3", "class_foo.html#a15ac327bfeab9942f561dcc535911424a9d07edb49658230a002d15802a668324", null ]
    ] ],
    [ "TEnum", "class_foo.html#a8321e2f90e0b1d6cdf21b3658903f049", [
      [ "TVal1", "class_foo.html#a8321e2f90e0b1d6cdf21b3658903f049a94dbec09d26b330c0d8442283274bc40", null ],
      [ "TVal2", "class_foo.html#a8321e2f90e0b1d6cdf21b3658903f049af3b249d6b7f2cab43964c35c85e37949", null ],
      [ "TVal3", "class_foo.html#a8321e2f90e0b1d6cdf21b3658903f049a9eb477c0d40f6a212fea7378412b1c47", null ]
    ] ],
    [ "Foo", "class_foo.html#a5c036d1b3561a0e1beffe8c6799a4276", null ],
    [ "~Foo", "class_foo.html#ab5d0e04c302f74429916d603e0fd8610", null ],
    [ "foo", "class_foo.html#ad9d1f4cdea946e64135e3432534cbaab", null ],
    [ "testSoma", "class_foo.html#a73ec38176e4e9975435a343f9dba5ccb", null ],
    [ "fooVar", "class_foo.html#ae350d327ccc45ab33a2d7bc42fe608b8", null ]
];