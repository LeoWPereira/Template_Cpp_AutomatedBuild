var _foo_8hpp =
[
    [ "Foo", "class_foo.html", "class_foo" ],
    [ "structTemplate", "struct_foo_1_1struct_template.html", "struct_foo_1_1struct_template" ],
    [ "MAX_INTEGER_VALUE", "_foo_8hpp.html#a74bbca0b51342a095149dd247d12c91e", null ],
    [ "integer", "_foo_8hpp.html#aa99b72987dca5e6532979f0852e6f033", null ]
];