var struct_foo_1_1struct_template =
[
    [ "valor1", "struct_foo_1_1struct_template.html#a44cbc474dd53408537cee3d225e48f2c", null ]
];