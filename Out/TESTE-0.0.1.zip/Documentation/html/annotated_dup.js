var annotated_dup =
[
    [ "Foo", "class_foo.html", "class_foo" ]
];